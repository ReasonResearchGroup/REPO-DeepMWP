import torch
import torch.nn as nn
from torch.autograd import Variable
import torch.nn.functional as F
from retrieval import Retrieval
from RNN import DNS
class Hybrid(nn.Module):
    def __init__(self, seq2seq, retrieval, cuda_use=False):
        super(Hybrid).__init__()
        self.seq2seq = seq2seq
        self.retrieval = retrieval
        self.cuda_use = cuda_sue
    def forward(self, input_variable, input_lengths=None, target_variable=None, retrieval_use=True, \
                rule_use=True,teacher_forcing_ratio=0,use_rule=True):
        simi_list=[]
        similarity=0
        if retrieval_use:
            similarity, gen_temp = self.retrieval.max_js(input_variable)
        if similarity > self.retrieval.theta:
            return [], None, gen_temp
        else:
            return self.seq2seq(input_variable, input_lengths, target_variable, teacher_forcing_ratio, self.cuda_use)
            